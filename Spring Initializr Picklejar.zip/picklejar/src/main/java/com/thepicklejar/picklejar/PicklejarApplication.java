package com.thepicklejar.picklejar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PicklejarApplication {

	public static void main(String[] args) {
		SpringApplication.run(PicklejarApplication.class, args);
	}

}
